package com.example.sankalp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SankalpApplication {

    public static void main(String[] args) {
        SpringApplication.run(SankalpApplication.class, args);
    }
}