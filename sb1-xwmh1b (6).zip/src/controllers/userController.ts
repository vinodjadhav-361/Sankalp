import { Request, Response } from 'express';
import User from '../models/User';
import Post from '../models/Post';
import Organization from '../models/Organization';

export const getUsers = async (req: Request, res: Response) => {
  try {
    const users = await User.find().select('-password');
    res.json(users);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching users', error });
  }
};

export const getUserById = async (req: Request, res: Response) => {
  try {
    const user = await User.findById(req.params.id).select('-password');
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    res.json(user);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching user', error });
  }
};

export const createUser = async (req: Request, res: Response) => {
  try {
    const newUser = new User(req.body);
    const savedUser = await newUser.save();
    res.status(201).json(savedUser);
  } catch (error) {
    res.status(400).json({ message: 'Error creating user', error });
  }
};

export const updateUser = async (req: Request, res: Response) => {
  try {
    const updatedUser = await User.findByIdAndUpdate(req.params.id, req.body, { new: true }).select('-password');
    if (!updatedUser) {
      return res.status(404).json({ message: 'User not found' });
    }
    res.json(updatedUser);
  } catch (error) {
    res.status(400).json({ message: 'Error updating user', error });
  }
};

export const deleteUser = async (req: Request, res: Response) => {
  try {
    const deletedUser = await User.findByIdAndDelete(req.params.id);
    if (!deletedUser) {
      return res.status(404).json({ message: 'User not found' });
    }
    res.json({ message: 'User deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Error deleting user', error });
  }
};

export const getUserPosts = async (req: Request, res: Response) => {
  try {
    const posts = await Post.find({ user: req.params.id }).populate('user', 'name handle avatar');
    res.json(posts);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching user posts', error });
  }
};

export const getUserOrganizations = async (req: Request, res: Response) => {
  try {
    const user = await User.findById(req.params.id).populate('organizations');
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    res.json(user.organizations);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching user organizations', error });
  }
};