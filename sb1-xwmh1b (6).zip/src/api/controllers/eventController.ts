import { Request, Response } from 'express';
import Event from '../../models/Event';

// Implement getEvents, getEventById, createEvent, updateEvent, deleteEvent