import { Request, Response } from 'express';
import Poll from '../../models/Poll';

// Implement getPolls, getPollById, createPoll, updatePoll, deletePoll, votePoll