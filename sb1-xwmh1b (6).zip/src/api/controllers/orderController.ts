import { Request, Response } from 'express';
import Order from '../../models/Order';

// Implement getOrders, getOrderById, createOrder, updateOrder, deleteOrder