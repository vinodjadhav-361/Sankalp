import { Request, Response } from 'express';
import Livestream from '../../models/Livestream';

// Implement getLivestreams, getLivestreamById, createLivestream, updateLivestream, deleteLivestream