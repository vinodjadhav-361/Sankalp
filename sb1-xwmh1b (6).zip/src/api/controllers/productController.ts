import { Request, Response } from 'express';
import Product from '../../models/Product';

// Implement getProducts, getProductById, createProduct, updateProduct, deleteProduct