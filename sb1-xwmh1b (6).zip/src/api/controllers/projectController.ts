import { Request, Response } from 'express';
import Project from '../../models/Project';

// Implement getProjects, getProjectById, createProject, updateProject, deleteProject